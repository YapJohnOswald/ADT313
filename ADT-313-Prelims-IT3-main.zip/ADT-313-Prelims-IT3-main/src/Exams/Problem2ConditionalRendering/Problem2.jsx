import React, { useState } from 'react';

function Problem2() {
  const user = {
    name: 'John Oswald',
    age: '20',
    nickname:'pogi',
    imageUrl: 'https://scontent.fmnl14-1.fna.fbcdn.net/v/t39.30808-6/457265676_8197205557007884_7778644038711276898_n.jpg?_nc_cat=108&ccb=1-7&_nc_sid=6ee11a&_nc_eui2=AeFetMb7aNtwtxLf2bQT08V9OgKuIEpNJYY6Aq4gSk0lhiwK60-hjigSSxvQ4KtSR1xUMDQQaxQkahJ0tc4y_OYU&_nc_ohc=wyhpmNVpUHgQ7kNvgGmbDRg&_nc_zt=23&_nc_ht=scontent.fmnl14-1.fna&_nc_gid=AAtV8OnaRW83qn3p2tVLzRe&oh=00_AYAwYoz2jxhU2BPAvrBqYTrZY6tNul45GDpERyegVOgikg&oe=6734833E',
    imageSize: 90,
    
  };

  function Profile() {
    return (
      <>
        <h1>{'Name: ' + user.name}</h1>
        <h2>{'Age: ' + user.age}</h2>
        <h2>{'Nickname: ' + user.nickname }</h2>
        <img
          className="avatar"
          src={user.imageUrl}
          alt={'Photo of ' + user.name + user.age + user.nickname }
          style={{
            width: user.imageSize,
            height: user.imageSize,
          }}
        />
      </>
    );
  }

  function InitialContent() {
    return <h1>User profile is hidden.</h1>;
  }

 
  const [isProfileVisible, setIsProfileVisible] = useState(false);


  const toggleProfileVisibility = () => {
    setIsProfileVisible((prevState) => !prevState);
  };

  return (
    <>
      <div>
        
        {isProfileVisible ? <Profile /> : <InitialContent />}
        <button type="button" onClick={toggleProfileVisibility}>
          {isProfileVisible ? 'Hide Profile' : 'Show Profile'}
        </button>
      </div>
    </>
  );
}

export default Problem2;