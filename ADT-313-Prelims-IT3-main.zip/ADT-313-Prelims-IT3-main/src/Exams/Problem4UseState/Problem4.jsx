import React, { useState } from 'react';

export default function Problem4() {
  const [formData, setFormData] = useState({
    name: '',
    yearLevel: '',
    course: 'BSCS',
  });

  
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };


  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(formData); 
    alert(JSON.stringify(formData, null, 2)); 
  };

  return (
    <form onSubmit={handleSubmit}>
      <div style={{ display: 'block' }}>
        Name: 
        <input 
          type='text' 
          name='name' 
          value={formData.name} 
          onChange={handleChange} 
        />
      </div>
      <div style={{ display: 'block' }}>
        <p>Year Level:</p>
        {['First Year', 'Second Year', 'Third Year', 'Fourth Year', 'Fifth Year', 'Irregular'].map((year) => (
          <div key={year}>
            <input
              type='radio'
              id={year}
              name='yearLevel'
              value={year}
              checked={formData.yearLevel === year}
              onChange={handleChange}
            />
            <label htmlFor={year}>{year}</label>
          </div>
        ))}
      </div>
      <div style={{ display: 'block' }}>
        Course:
        <select name='course' value={formData.course} onChange={handleChange}>
          <option value='BSCS'>BSCS</option>
          <option value='BSIT'>BSIT</option>
          <option value='BSCpE'>BSCpE</option>
          <option value='ACT'>ACT</option>
        </select>
      </div>
      <button type='submit'>Submit</button>
    </form>
  );
}